﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//DOM = Document Object Model

namespace SeleniumFirstA
{
    class Program
    {

        static void Main(string[] args)
        {

        }

        [SetUp]

        public void Initialize()
        {

            //create reference for the browser
            PropertiesCollection.driver = new ChromeDriver();

            PropertiesCollection.driver.Navigate().GoToUrl("http://executeautomation.com/demosite/index.html?UserName=&Password=&Login=Login");

            //driver.Navigate().GoToUrl("http://google.com");

            Console.WriteLine("Open the URL");
        }

        [Test]

        public void ExecuteTests()
        {

            //Title selection

            SeleniumSetMethodsAH.SelectDropDown("TitleId", "Mr.", PropertyType.Id);

            //Enter Initial

            SeleniumSetMethodsAH.EnterText("Initial", "AH", PropertyType.Name);

            //Click on the button

            SeleniumSetMethodsAH.Click("Save", PropertyType.Name);

            // Get calls
            Console.WriteLine("The value of the Initial is :" + SeleniumGetMethodsAH.GetTextFromDDL("TitleId", PropertyType.Id));

            Console.WriteLine("The value of the TitleId is :" + SeleniumGetMethodsAH.GetText("Initial", PropertyType.Name));
        }

        [Test]

        public void NextMethod()
        {
            Console.WriteLine("Next Test Method");
        }

        [TearDown]

        public void CleanUp()
        {
            //close browser
            PropertiesCollection.driver.Close();

            Console.WriteLine("Close the browser");
        }


    }
}
