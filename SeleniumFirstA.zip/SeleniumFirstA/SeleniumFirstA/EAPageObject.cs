﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumFirstA
{
    class EAPageObject
    {

        //type ctor and then press tab key twice and it adds the Constructor
        //public EAPageObject() // obsoleted...
        //{

        //    SeleniumExtras.PageFactory.InitElements(PropertiesCollection.driver, this);

        //}

        [FindsBy (How = How.Id, Using = "TitleId")]

        public IWebElement ddlTitleId{get; set; }

        [FindsBy(How = How.Name, Using = "Initial")]

        public IWebElement txtInitial { get; set; }

        [FindsBy(How = How.Name, Using = "Save")]

        public IWebElement btnSave { get; set; }
    }
}
