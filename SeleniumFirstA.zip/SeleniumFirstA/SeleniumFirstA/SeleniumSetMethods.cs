﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;

namespace SeleniumFirstA
{
    class SeleniumSetMethods
    {

        //custom method to enter text by identifying the object on the page

        public static void EnterText(IWebDriver driver, string element, string value, string elementtype)
        {

            //IWebElement element = driver.FindElement(By.Name("q"));
            //IWebElement elementA = driver.FindElement(By.ClassName("gb_P"));
            if (elementtype == "Id")
            {
                driver.FindElement(By.Id(element)).SendKeys(value);

            }

            if (elementtype == "Name")
                driver.FindElement(By.Name(element)).SendKeys(value);

        }

        //custom method to click on a specific object
        public static void Click(IWebDriver driver, string element, string elementtype)
        {

            if (elementtype == "Id")
                driver.FindElement(By.Id(element)).Click();

            if (elementtype == "Name")
                driver.FindElement(By.Name(element)).Click();
        }

        //custom method to select drop down option
        public static void SelectDropDown (IWebDriver driver, string element, string value, string elementtype)
        {

            if (elementtype == "Id")
                new SelectElement(driver.FindElement(By.Id(element))).SelectByText(value);

            if (elementtype == "Name")
                new SelectElement(driver.FindElement(By.Name(element))).SelectByText(value);
        }


    }
}
