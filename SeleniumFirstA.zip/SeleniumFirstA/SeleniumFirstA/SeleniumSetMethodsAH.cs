﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;

namespace SeleniumFirstA
{
    class SeleniumSetMethodsAH
    {

        //custom method to enter text by identifying the object on the page

        public static void EnterText(string element, string value, PropertyType elementtype)
        {

            //IWebElement element = driver.FindElement(By.Name("q"));
            //IWebElement elementA = driver.FindElement(By.ClassName("gb_P"));
            if (elementtype == PropertyType.Id)
            {
                PropertiesCollection.driver.FindElement(By.Id(element)).SendKeys(value);

            }

            if (elementtype == PropertyType.Name)
                PropertiesCollection.driver.FindElement(By.Name(element)).SendKeys(value);

        }

        //custom method to click on a specific object
        public static void Click(string element, PropertyType elementtype)
        {

            if (elementtype == PropertyType.Id)
                PropertiesCollection.driver.FindElement(By.Id(element)).Click();

            if (elementtype == PropertyType.Name)
                PropertiesCollection.driver.FindElement(By.Name(element)).Click();
        }

        //custom method to select drop down option
        public static void SelectDropDown(string element, string value, PropertyType elementtype)
        {

            if (elementtype == PropertyType.Id)
                new SelectElement(PropertiesCollection.driver.FindElement(By.Id(element))).SelectByText(value);

            if (elementtype == PropertyType.Name)
                new SelectElement(PropertiesCollection.driver.FindElement(By.Name(element))).SelectByText(value);
        }

        ////custom method to select drop down option
        //public static void SelectRadioCheck(string element, Boolean value, PropertyType elementtype)
        //{

        //    //if (elementtype == PropertyType.Id)
        //    //    new SelectElement(PropertiesCollection.driver.FindElement(By.Id(element))).SelectByText(value);

        //    //if (elementtype == PropertyType.Name)
        //    //    new SelectElement(PropertiesCollection.driver.FindElement(By.Name(element))).

        //    // Step 3 : Select the deselected Radio button (Male) for category Sex (Use IsSelected method)
        //    // Storing all the elements under category 'Sex' in the list of WebLements	
        //    IList<IWebElement> rdBtn_Gender = PropertiesCollection.driver.FindElements(By.Name("Male"));

        //    Boolean bValue = false;

        //    // This statement will return True, in case of first Radio button is selected
        //    bValue = rdBtn_Gender.ElementAt(0).Selected;

        //    // This will check that if the bValue is True means if the first radio button is selected
        //    if (bValue == true)
        //    {
        //        // This will select Second radio button, if the first radio button is selected by default
        //        rdBtn_Sex.ElementAt(1).Click();
        //    }
        //    else
        //    {
        //        // If the first radio button is not selected by default, the first will be selected
        //        rdBtn_Sex.ElementAt(0).Click();
        //    }

        //}


    }
}
