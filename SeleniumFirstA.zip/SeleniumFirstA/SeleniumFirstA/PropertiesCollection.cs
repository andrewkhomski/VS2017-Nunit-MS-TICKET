﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumFirstA
{

    // strongly typed - prevent from making mistakes while coding, since the enam defines a specific list
    enum PropertyType
    {
        Id,
        Name,
        LinkText,
        CssName,
        ClassName
    }


    public enum bResult
    {
        TRUE,
        FALSE
    }

    class PropertiesCollection
    {
                
        //Auto-implemented properties
        public static IWebDriver driver { get; set; }



    }
}
